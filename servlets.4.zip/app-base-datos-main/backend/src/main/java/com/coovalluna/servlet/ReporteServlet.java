package com.coovalluna.servlet;

import com.coovalluna.dao.ReporteDAO;
import com.coovalluna.util.CorsUtil;
import com.coovalluna.util.JsonUtil;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

/**
 * ReporteServlet — GET /api/reportes/{id}
 *
 * Rutas disponibles:
 *
 *  R1  /api/reportes/1   Asociados por estado y agencia
 *        ?estado=activo|inactivo|suspendido
 *        ?agencia=COD_AGENCIA
 *
 *  R2  /api/reportes/2   Extracto de cuenta
 *        ?numeroCuenta=XXXXXXXX          (REQUERIDO)
 *        ?desde=2024-01-01 00:00:00
 *        ?hasta=2024-12-31 23:59:59
 *        ?tipo=deposito|retiro|transferencia_entrante|transferencia_saliente
 *        ?canal=cajero|app|oficina|web
 *
 *  R3  /api/reportes/3   Cartera de créditos por línea y estado
 *        ?agencia=COD_AGENCIA
 *        ?desde=2024-01-01
 *        ?hasta=2024-12-31
 *
 *  R4  /api/reportes/4   Asociados en mora (sin filtros; calculado al día de hoy)
 *
 *  R5  /api/reportes/5   Historial de pagos de un crédito
 *        ?radicado=RAD-XXXX              (REQUERIDO)
 *
 *  R6  /api/reportes/6   Productividad de asesores
 *        ?agencia=COD_AGENCIA
 *        ?desde=2024-01-01
 *        ?hasta=2024-12-31
 *
 *  R7  /api/reportes/7   Créditos con codeudor (sin filtros)
 */
@WebServlet("/api/reportes/*")
public class ReporteServlet extends HttpServlet {

    private final ReporteDAO reporteDAO = new ReporteDAO();

    // ------------------------------------------------------------------ OPTIONS
    @Override
    protected void doOptions(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        CorsUtil.setCorsHeaders(resp);
        resp.setStatus(HttpServletResponse.SC_OK);
    }

    // ------------------------------------------------------------------ GET
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        CorsUtil.setCorsHeaders(resp);

        // Extraer el número de reporte de la URL: /api/reportes/{id}
        String pathInfo = req.getPathInfo(); // ej. "/1" o "/1/"
        if (pathInfo == null || pathInfo.equals("/")) {
            JsonUtil.sendError(resp, HttpServletResponse.SC_BAD_REQUEST,
                    "Indique el número de reporte: /api/reportes/{1..7}");
            return;
        }

        String reporteId = pathInfo.replaceAll("^/|/$", ""); // quitar barras

        try {
            switch (reporteId) {
                case "1" -> handleR1(req, resp);
                case "2" -> handleR2(req, resp);
                case "3" -> handleR3(req, resp);
                case "4" -> handleR4(req, resp);
                case "5" -> handleR5(req, resp);
                case "6" -> handleR6(req, resp);
                case "7" -> handleR7(req, resp);
                default  -> JsonUtil.sendError(resp, HttpServletResponse.SC_NOT_FOUND,
                        "Reporte '" + reporteId + "' no existe. Use un número del 1 al 7.");
            }
        } catch (SQLException e) {
            JsonUtil.sendError(resp, HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    "Error al ejecutar el reporte: " + e.getMessage());
        }
    }

    // ============================================================= REPORTE 1
    /**
     * R1 — Asociados por estado y agencia.
     * Muestra cédula, nombres, apellidos, tipo_asociado, fecha_afiliacion, estado
     * y cantidad de cuentas activas. Filtrable por estado y/o código de agencia.
     */
    private void handleR1(HttpServletRequest req, HttpServletResponse resp)
            throws SQLException, IOException {
        String estado  = trim(req.getParameter("estado"));
        String agencia = trim(req.getParameter("agencia"));

        List<Map<String, Object>> resultado =
                reporteDAO.r1AsociadosPorEstadoYAgencia(estado, agencia);
        JsonUtil.sendJson(resp, resultado);
    }

    // ============================================================= REPORTE 2
    /**
     * R2 — Extracto de cuenta (movimientos).
     * Requiere numeroCuenta. Filtros opcionales: rango de fechas, tipo de
     * movimiento y canal.
     */
    private void handleR2(HttpServletRequest req, HttpServletResponse resp)
            throws SQLException, IOException {
        String numeroCuenta = trim(req.getParameter("numeroCuenta"));
        if (numeroCuenta == null) {
            JsonUtil.sendError(resp, HttpServletResponse.SC_BAD_REQUEST,
                    "El parámetro 'numeroCuenta' es requerido para el reporte 2.");
            return;
        }
        String desde = trim(req.getParameter("desde")); // "2024-01-01 00:00:00"
        String hasta = trim(req.getParameter("hasta")); // "2024-12-31 23:59:59"
        String tipo  = trim(req.getParameter("tipo"));  // deposito | retiro | ...
        String canal = trim(req.getParameter("canal")); // cajero | app | oficina | web

        List<Map<String, Object>> resultado =
                reporteDAO.r2ExtractoCuenta(numeroCuenta, desde, hasta, tipo, canal);
        JsonUtil.sendJson(resp, resultado);
    }

    // ============================================================= REPORTE 3
    /**
     * R3 — Cartera de créditos agrupada por línea y estado.
     * Devuelve conteo, total aprobado y porcentaje por combinación.
     * Filtros opcionales: agencia, rango de fechas de aprobación.
     */
    private void handleR3(HttpServletRequest req, HttpServletResponse resp)
            throws SQLException, IOException {
        String agencia = trim(req.getParameter("agencia"));
        String desde   = trim(req.getParameter("desde")); // "2024-01-01"
        String hasta   = trim(req.getParameter("hasta")); // "2024-12-31"

        List<Map<String, Object>> resultado =
                reporteDAO.r3CarteraPorLineaYEstado(agencia, desde, hasta);
        JsonUtil.sendJson(resp, resultado);
    }

    // ============================================================= REPORTE 4
    /**
     * R4 — Asociados en mora.
     * Calcula al día de hoy cuotas vencidas pendientes o pagadas con mora.
     * No requiere filtros; el cálculo es dinámico contra CURRENT_DATE.
     */
    private void handleR4(HttpServletRequest req, HttpServletResponse resp)
            throws SQLException, IOException {
        List<Map<String, Object>> resultado = reporteDAO.r4AsociadosEnMora();
        JsonUtil.sendJson(resp, resultado);
    }

    // ============================================================= REPORTE 5
    /**
     * R5 — Historial de pagos de un crédito.
     * Requiere el número de radicado. Lista todas las cuotas con su fecha de
     * vencimiento, fecha de pago, valor pagado y estado.
     */
    private void handleR5(HttpServletRequest req, HttpServletResponse resp)
            throws SQLException, IOException {
        String radicado = trim(req.getParameter("radicado"));
        if (radicado == null) {
            JsonUtil.sendError(resp, HttpServletResponse.SC_BAD_REQUEST,
                    "El parámetro 'radicado' es requerido para el reporte 5.");
            return;
        }

        List<Map<String, Object>> resultado = reporteDAO.r5HistorialPagos(radicado);
        JsonUtil.sendJson(resp, resultado);
    }

    // ============================================================= REPORTE 6
    /**
     * R6 — Productividad de asesores.
     * Devuelve, por asesor: asociados atendidos, créditos radicados, valor total
     * aprobado y cuentas abiertas. Filtros opcionales: agencia y rango de fechas.
     */
    private void handleR6(HttpServletRequest req, HttpServletResponse resp)
            throws SQLException, IOException {
        String agencia = trim(req.getParameter("agencia"));
        String desde   = trim(req.getParameter("desde")); // "2024-01-01"
        String hasta   = trim(req.getParameter("hasta")); // "2024-12-31"

        List<Map<String, Object>> resultado =
                reporteDAO.r6ProductividadAsesores(agencia, desde, hasta);
        JsonUtil.sendJson(resp, resultado);
    }

    // ============================================================= REPORTE 7
    /**
     * R7 — Créditos con codeudor.
     * Lista titular, crédito, codeudor y fecha de firma del pagaré.
     * No requiere filtros.
     */
    private void handleR7(HttpServletRequest req, HttpServletResponse resp)
            throws SQLException, IOException {
        List<Map<String, Object>> resultado = reporteDAO.r7CreditosConCodeudor();
        JsonUtil.sendJson(resp, resultado);
    }

    // ------------------------------------------------------------------ helper
    private String trim(String value) {
        if (value == null || value.isBlank()) return null;
        return value.trim();
    }
}
